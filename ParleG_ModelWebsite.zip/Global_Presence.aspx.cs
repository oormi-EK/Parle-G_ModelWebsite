﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class WebForm7 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void ImageMap1_Click(object sender, ImageMapEventArgs e)
        {
            
            string i;
            i = e.PostBackValue.ToString();
           // Label1.Text = i;
            if(i.Equals("10"))
            {
                BulletedList1.Items.Clear();
                Label1.Text = "India";
                BulletedList1.Items.Add("BakeSmith English Marie");
                BulletedList1.Items.Add("Parle-G Range");
                BulletedList1.Items.Add("20-20 Cookies Range");
                BulletedList1.Items.Add("Monaco Range");
                BulletedList1.Items.Add("Parle Top Range");
                Label1.Visible = true;
                Panel1.Visible = true;
            }
            if (i.Equals("20"))
            {
                BulletedList1.Items.Clear();
                Label1.Text = "Madagascar";
                BulletedList1.Items.Add("BakeSmith English Marie");
                BulletedList1.Items.Add("Parle-G Range");
                BulletedList1.Items.Add("Hide & Seek Range");
                BulletedList1.Items.Add("Fab! Milky Sandwich");
                BulletedList1.Items.Add("Milk Shakti Strawberry & Milk");
                Label1.Visible = true;
                Panel1.Visible = true;
            }
            if (i.Equals("30"))
            {
                BulletedList1.Items.Clear();
                Label1.Text = "Australia";
                BulletedList1.Items.Add("BakeSmith English Marie");
                BulletedList1.Items.Add("Parle-G Range");
                BulletedList1.Items.Add("Hide & Seek Range");
                BulletedList1.Items.Add("Fab! Bourbon");
                BulletedList1.Items.Add("Hide And Seek Fab! Starwberry");
                Label1.Visible = true;
                Panel1.Visible = true;
            }
            if (i.Equals("40"))
            {
                BulletedList1.Items.Clear();
                Label1.Text = "Singapore";
                BulletedList1.Items.Add("BakeSmith English Marie");
                BulletedList1.Items.Add("Parle-G Range");
                BulletedList1.Items.Add("Hide & Seek Range");
                BulletedList1.Items.Add("Hide & Seek Caffe Mocha");
                BulletedList1.Items.Add("Fab! Bourbon");
                Label1.Visible = true;
                Panel1.Visible = true;
            }
            if (i.Equals("50"))
            {
                BulletedList1.Items.Clear();
                Label1.Text = "Kenya";
                BulletedList1.Items.Add("BakeSmith English Marie");
                BulletedList1.Items.Add("Parle-G Range");
                BulletedList1.Items.Add("Monoco Range");
                BulletedList1.Items.Add("Parle Top Range");
                BulletedList1.Items.Add("20-20 Cookies Range");
                Label1.Visible = true;
                Panel1.Visible = true;
            }


        }
    }
}