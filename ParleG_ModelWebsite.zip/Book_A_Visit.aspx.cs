﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class WebForm6 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList5.SelectedItem.Text.Equals("Ahemdabad, Gujarat"))
            {
                Label3.Text = "Bhupendra";
                Label5.Text = "lao_more_ahm@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Ajmer, Rajasthan"))
            {
                Label3.Text = "Devraj Singh";
                Label5.Text = "ajmer_foods_ajm@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Bhavnagar, Gujarat"))
            {
                Label3.Text = "Ketan Mehta";
                Label5.Text = "gpmanglani_bhv@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Chennai, Tamilnadu"))
            {
                Label3.Text = "Priya";
                Label5.Text = "moedern_chennai@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Madurai, Tamilnadu"))
            {
                Label3.Text = "Rajiv";
                Label5.Text = "patwari_mdu@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Jabalpur, Madhya Pradesh"))
            {
                Label3.Text = "Anil Singh Rajput";
                Label5.Text = "balaji_edi_jab@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Patna, Bihar"))
            {
                Label3.Text = "Kishore Kumar";
                Label5.Text = "lucky_bis_pat@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Satara, Maharashtra"))
            {
                Label3.Text = "Kishore Kumar";
                Label5.Text = "lucky_bis_pat@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            if (DropDownList5.SelectedItem.Text.Equals("Varanasi, Uttar Pradesh"))
            {
                Label3.Text = "Ajit Srivastava";
                Label5.Text = "mp_bis_vns@parle.biz";
                Label7.Text = DropDownList5.SelectedItem.ToString();
            }
            Panel1.Visible = true;
        }
    }
}