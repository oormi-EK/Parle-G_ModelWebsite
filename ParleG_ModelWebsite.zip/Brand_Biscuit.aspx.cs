﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList1.SelectedItem.Text.Equals("20-20 Cookies Range"))
            {
                Image4.ImageUrl = "~/images/b1.PNG";
                Image5.ImageUrl = "~/images/b2.PNG";
                Image6.ImageUrl = "~/images/b3.PNG";
                Image7.ImageUrl = "~/images/b4.PNG";
                Image8.ImageUrl = "~/images/b5.jpg";
            }
            if(DropDownList1.SelectedItem.Text.Equals("Happy Happy Range"))
            {
                Image4.ImageUrl = "~/images/h1.PNG";
                Image5.ImageUrl = "~/images/h2.PNG";
                Image6.ImageUrl = "~/images/h5.PNG";
                Image7.ImageUrl = "~/images/h3.PNG";
                Image8.ImageUrl = "~/images/h4.PNG";
            }
            if(DropDownList1.SelectedItem.Text.Equals("Hide & Seek Range"))
            {
                Image4.ImageUrl = "~/images/hs1.PNG";
                Image5.ImageUrl = "~/images/hs2.PNG";
                Image6.ImageUrl = "~/images/hs5.PNG";
                Image7.ImageUrl = "~/images/hs3.PNG";
                Image8.ImageUrl = "~/images/hs4.PNG";
            }
            if(DropDownList1.SelectedItem.Text.Equals("Magix Creme Range"))
            {
                Image4.ImageUrl = "~/images/m1.PNG";
                Image5.ImageUrl = "~/images/m2.PNG";
                Image6.ImageUrl = "~/images/m5.PNG";
                Image7.ImageUrl = "~/images/m3.PNG";
                Image8.ImageUrl = "~/images/m4.PNG";
            }
            if(DropDownList1.SelectedItem.Text.Equals("Monoco Range"))
            {
                Image4.ImageUrl = "~/images/mn1.PNG";
                Image5.ImageUrl = "~/images/mn2.PNG";
                Image6.ImageUrl = "~/images/mn5.PNG";
                Image7.ImageUrl = "~/images/mn3.PNG";
                Image8.ImageUrl = "~/images/mn4.PNG";
            }
        }
    }
}