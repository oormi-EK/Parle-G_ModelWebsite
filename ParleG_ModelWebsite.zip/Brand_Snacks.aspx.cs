﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Assign1
{
    public partial class WebForm4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DropDownList2.SelectedItem.Text.Equals("Chatkeens Namkeen Range"))
            {
                Image7.ImageUrl = "~/images/sn1.PNG";
                Image8.ImageUrl = "~/images/sn2.PNG";
                Image9.ImageUrl = "~/images/sn3.PNG";
            }
            if(DropDownList2.SelectedItem.Text.Equals("Fulltoss Range"))
            {
                Image7.ImageUrl = "~/images/sn5.PNG";
                Image8.ImageUrl = "~/images/sn6.PNG";
                Image9.ImageUrl = "~/images/sn7.PNG";
            }
            if(DropDownList2.SelectedItem.Text.Equals("Mexitos Range"))
            {
                Image7.ImageUrl = "~/images/sn8.PNG";
                Image8.ImageUrl = "~/images/sn9.PNG";
                Image9.ImageUrl = "~/images/sn10.PNG";
            }
            if(DropDownList2.SelectedItem.Text.Equals("Parle's Wafers Range"))
            {
                Image7.ImageUrl = "~/images/sn11.PNG";
                Image8.ImageUrl = "~/images/sn12.PNG";
                Image9.ImageUrl = "~/images/sn13.PNG";
            }
        }
    }
}